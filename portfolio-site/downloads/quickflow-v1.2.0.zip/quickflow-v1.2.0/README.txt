QuickFlow v1.2.0
================
极简任务与时间管理工具。

运行方式：
  - Windows: 双击 QuickFlow.exe
  - macOS:   打开 QuickFlow.app

首次使用无需注册，所有数据保存在本地。
如需帮助，请查看 product-manual.md。

© 2026 陈墨
